<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    public function update(Request $request)
    {
        $user = $request->user();

        $request->validate([
            'profile_photo' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('profile_photo')) {
            $file = $request->file('profile_photo');
            // Genera un nombre único
            $filename = 'user_' . $user->id . '_' . time() . '.' . $file->getClientOriginalExtension();
            // Almacena el archivo en la carpeta 'profile_photos' en el disco 'public'
            $path = $file->storeAs('profile_photos', $filename, 'public');
            // Guarda la URL completa
            $user->profile_photo = asset('storage/' . $path);
        }

        $user->save();

        return response()->json($user, 200);
    }

}
