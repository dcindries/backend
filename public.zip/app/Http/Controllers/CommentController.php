<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comment;

class CommentController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'post_id' => 'required|exists:posts,id',
            'content' => 'required|string',
        ]);

        $comment = Comment::create([
            'post_id' => $request->input('post_id'),
            'user_id' => $request->user()->id,
            'content' => $request->input('content'),
        ]);

        return response()->json($comment, 201);
    }


    // Opcional: eliminar un comentario
    public function destroy($id)
    {
        $comment = Comment::findOrFail($id);
        if ($comment->user_id !== auth()->id()) {
            return response()->json(['message' => 'No tienes permiso para eliminar este comentario.'], 403);
        }

        $comment->delete();
        return response()->json(['message' => 'Comentario eliminado.'], 200);
    }
}
