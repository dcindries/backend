<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Exception;

class PostController extends Controller
{
    public function index(Request $request)
    {
        if ($request->has('group_id')) {
            $groupId = $request->query('group_id');
            $posts = Post::with(['comments.user'])->where('group_id', $groupId)->get();
        } else {
            $posts = Post::with(['comments.user'])->get();
        }
        return response()->json($posts, 200);
    }



    public function store(Request $request)
    {
        $request->validate([
            'content' => 'nullable|string',
            'group_id' => 'required|exists:groups,id',
            'image' => 'nullable|image|max:2048'
        ]);

        $imageUrl = null;
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = 'post_' . time() . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('post_images', $filename, 'public');
            $imageUrl = asset('storage/' . $path);
        }

        $post = Post::create([
            'content' => $request->input('content'),
            'image_path' => $imageUrl,
            'group_id' => $request->input('group_id'),
            'created_by' => $request->user()->id,
        ]);

        return response()->json($post, 201);
    }


    public function show($id)
    {
        try {
            $post = Post::findOrFail($id);
            return response()->json($post, 200);
        } catch (Exception $e) {
            return response()->json([
                'message' => 'Publicación no encontrada',
                'error'   => $e->getMessage()
            ], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $post = Post::findOrFail($id);

            $request->validate([
                'content' => 'nullable|string',
                'image_path' => 'nullable|string',
            ]);

            $post->update($request->all());
            return response()->json($post, 200);
        } catch (Exception $e) {
            return response()->json([
                'message' => 'Error al actualizar la publicación',
                'error'   => $e->getMessage()
            ], 500);
        }
    }

    public function destroy($id)
    {
        try {
            $post = Post::findOrFail($id);
            $post->delete();
            return response()->json(['message' => 'Publicación eliminada'], 200);
        } catch (Exception $e) {
            return response()->json([
                'message' => 'Error al eliminar la publicación',
                'error'   => $e->getMessage()
            ], 500);
        }
    }
}
