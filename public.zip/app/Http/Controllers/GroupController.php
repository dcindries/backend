<?php

namespace App\Http\Controllers;

use App\Models\Group;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Laravel\Sanctum\PersonalAccessToken;

class GroupController extends Controller
{
    // Listar todos los grupos públicos
    public function index()
    {
        return response()->json(
            Group::withCount('members')
                ->where('is_public', true)
                ->get(),
            200
        );
    }

    // Mostrar detalle (público o privado si eres miembro)
    public function show(Request $request, $id)
    {
        $group = Group::withCount('members')->findOrFail($id);

        // Obtener usuario autenticado (incluyendo token manual)
        $user = auth()->user();
        if (!$user && $request->header('Authorization')) {
            if ($pat = PersonalAccessToken::findToken($request->bearerToken())) {
                $user = $pat->tokenable;
            }
        }

        $isMember = $user
            ? $group->members()->where('user_id', $user->id)->exists()
            : false;

        // Si es privado y no eres miembro, 403
        if (!$group->is_public && !$isMember) {
            return response()->json(['message'=>'Acceso denegado'], 403);
        }

        return response()->json([
            'group'    => $group,
            'isMember' => $isMember
        ], 200);
    }

    // Crear grupo (y unir creador automáticamente)
    public function store(Request $request)
    {
        $data = $request->validate([
            'name'        => 'required|string|max:255',
            'description' => 'nullable|string',
            'is_public'   => 'required|boolean',
        ]);

        $user = $request->user();
        $data['access_key'] = $data['is_public']
            ? null
            : Str::random(8);
        $data['created_by'] = $user->id;

        $group = Group::create($data);

        // Auto-unir al creador
        $group->members()->attach($user->id);

        // Devolver con recuento de miembros
        return response()->json(
            Group::withCount('members')->find($group->id),
            201
        );
    }

    // Actualizar grupo (solo creador)
    public function update(Request $request, $id)
    {
        $group = Group::findOrFail($id);
        $user  = $request->user();
        if ($group->created_by !== $user->id) {
            return response()->json(['message'=>'No autorizado'], 403);
        }

        $data = $request->validate([
            'name'        => 'sometimes|required|string|max:255',
            'description' => 'nullable|string',
            'is_public'   => 'sometimes|required|boolean',
        ]);

        // Si pasa de público a privado sin clave, generar una
        if (isset($data['is_public']) && !$data['is_public'] && !$group->access_key) {
            $group->access_key = Str::random(8);
        }

        $group->update($data);

        return response()->json(
            $group->fresh()->loadCount('members'),
            200
        );
    }

    // Eliminar grupo (solo creador)
    public function destroy(Request $request, $id)
    {
        $group = Group::findOrFail($id);
        if ($group->created_by !== $request->user()->id) {
            return response()->json(['message'=>'No autorizado'], 403);
        }
        $group->delete();
        return response()->json(['message'=>'Grupo eliminado'], 200);
    }

    // Unirse a un grupo (valida clave en privados)
    public function join(Request $request, $id)
    {
        $group = Group::findOrFail($id);
        $user  = $request->user();

        if (!$group->is_public) {
            $key = $request->input('access_key');
            if (!$key || $key !== $group->access_key) {
                return response()->json(['message'=>'Clave inválida'], 403);
            }
        }

        if ($group->members()->where('user_id',$user->id)->exists()) {
            return response()->json(['message'=>'Ya eres miembro'], 409);
        }

        $group->members()->attach($user->id);
        return response()->json(['message'=>'Unido al grupo'], 200);
    }

    // Abandonar grupo:
    // • Si no quedan miembros → eliminar grupo
    // • Si quedan → promueve al miembro más antiguo (pivot.created_at)
    public function leave(Request $request, $id)
    {
        $group = Group::findOrFail($id);
        $user  = $request->user();

        if (!$group->members()->where('user_id',$user->id)->exists()) {
            return response()->json(['message'=>'No eres miembro'], 409);
        }

        // Desvincular
        $group->members()->detach($user->id);

        // Obtener restantes ordenados por fecha de unión
        $remaining = $group->members()
            ->withPivot('created_at')
            ->orderBy('group_user.created_at','asc')
            ->get();

        if ($remaining->isEmpty()) {
            $group->delete();
            return response()->json([
                'message'=>'Has abandonado; el grupo se eliminó (sin miembros restantes)'
            ], 200);
        }

        // Promover al más antiguo
        $newCreator = $remaining->first();
        $group->created_by = $newCreator->id;
        $group->save();

        return response()->json([
            'message'=>'Has abandonado el grupo',
            'new_creator'=>$newCreator->id
        ], 200);
    }

    // Listar grupos privados del usuario
    public function myPrivateGroups(Request $request)
    {
        $user = $request->user();
        $groups = $user->groups()
            ->where('is_public', false)
            ->withCount('members')
            ->get()
            ->transform(function($g) use($user){
                if ($g->created_by !== $user->id) {
                    unset($g->access_key);
                }
                return $g;
            });

        return response()->json($groups, 200);
    }



    public function joinByCode(Request $request)
    {
        $data = $request->validate([
            'access_key' => 'required|string'
        ]);

        $user = $request->user();
        $key  = $data['access_key'];

        // Buscar grupo con esa clave
        $group = Group::where('access_key', $key)->first();
        if (! $group) {
            return response()->json([
                'message' => 'Clave de grupo inválida.'
            ], 404);
        }

        // Si ya es miembro
        if ($group->members()->where('user_id', $user->id)->exists()) {
            return response()->json([
                'message' => 'Ya eres miembro de este grupo.'
            ], 409);
        }

        // Adjuntar al usuario
        $group->members()->attach($user->id);

        return response()->json([
            'message' => "Te has unido al grupo '{$group->name}' exitosamente."
        ], 200);
    }


}
