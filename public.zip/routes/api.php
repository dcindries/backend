<?php

use App\Http\Controllers\CommentController;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\GroupController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\UserController;



Route::middleware('auth:sanctum')->get('my-private-groups', function (Request $request) {
    // Obtén los grupos privados a los que pertenece el usuario
    $user = $request->user();
    $groups = $user->groups()->where('is_public', false)->withCount('members')->get();

    // Para cada grupo, si el usuario no es el creador, oculta la clave de acceso.
    $groups->transform(function ($group) use ($user) {
        if ($group->created_by !== $user->id) {
            unset($group->access_key);
        }
        return $group;
    });

    return response()->json($groups, 200);
});


Route::middleware('auth:sanctum')->get('my-groups', function (Request $request) {
    return response()->json($request->user()->groups()->withCount('members')->get());
});
// Rutas protegidas para obtener y actualizar el usuario
Route::middleware('auth:sanctum')->group(function () {
    Route::get('user', function (Request $request) {
        return response()->json($request->user());
    });

    Route::put('user', [UserController::class, 'update']);
});


// Rutas de autenticación públicas
Route::controller(RegisteredUserController::class)->group(function () {
    Route::post('register', 'store');
});

Route::controller(AuthenticatedSessionController::class)->group(function () {
    Route::post('login', 'store');
    Route::delete('logout', 'destroy')->middleware('auth:sanctum');
});


// Rutas públicas para grupos
Route::controller(GroupController::class)->group(function () {
    Route::get('groups', 'index');
    Route::get('groups/{id}', 'show');
});

// Rutas protegidas para grupos
Route::middleware('auth:sanctum')->group(function () {
    Route::controller(GroupController::class)->group(function () {
        Route::post('groups', 'store');
        Route::put('groups/{id}', 'update');
        Route::delete('groups/{id}', 'destroy');
        Route::post('groups/{id}/join', 'join');
        Route::post('groups/{id}/leave', 'leave');
        Route::post('groups/join-by-code', 'joinByCode');
    });
});


// Rutas públicas para posts
Route::controller(PostController::class)->group(function () {
    Route::get('posts', 'index');
    Route::get('posts/{id}', 'show');
});

// Rutas protegidas para posts
Route::middleware('auth:sanctum')->group(function () {
    Route::controller(PostController::class)->group(function () {
        Route::post('posts', 'store');
        Route::put('posts/{id}', 'update');
        Route::delete('posts/{id}', 'destroy');
    });

//RUTAS COMMENTS
Route::middleware('auth:sanctum')->group(function () {
    Route::post('comments', [CommentController::class, 'store']);
    Route::delete('comments/{id}', [CommentController::class, 'destroy']);
});
});
