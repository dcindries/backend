<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'profile_photo',
        'role'
    ];

    // Hacemos que al serializar a JSON aparezca siempre este atributo:
    protected $appends = ['is_admin'];

    /**
     * Devuelve true si este usuario es el administrador (id = 1).
     */
    public function getIsAdminAttribute(): bool
    {
        return $this->id === 1;
    }

    public function groups()
    {
        return $this->belongsToMany(Group::class, 'group_user')->withTimestamps();
    }
}
