<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;  // ✱ Importa Hash

class UserController extends Controller
{

    // app/Http/Controllers/UserController.php

    public function index()
    {
        // Selecciona únicamente los campos obligatorios en tu tabla users
        $users = User::select('id', 'name', 'email')->get();

        return response()->json($users, 200);
    }


    public function __construct()
    {
        // 1) Asegura que venga un token Sanctum válido
        $this->middleware('auth:sanctum');

        // 2) Inyecta el closure que verifica email y contraseña
        $this->middleware(function (Request $request, $next) {
            $user = $request->user();

            // Comprueba email y contraseña (Hash::check si está hasheada en BD)
            $isAdminEmail    = $user->email === 'admin@gmail.com';
            $isAdminPassword = Hash::check('12345678', $user->password);

            if (! ($isAdminEmail && $isAdminPassword)) {
                return response()->json([
                    'message' => 'Acceso denegado: solo administrador'
                ], 403);
            }

            return $next($request);
        });
    }

    public function update(Request $request)
    {
        $user = $request->user();

        $request->validate([
            'profile_photo' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('profile_photo')) {
            $file     = $request->file('profile_photo');
            $filename = 'user_' . $user->id . '_' . time() . '.' . $file->getClientOriginalExtension();
            $path     = $file->storeAs('profile_photos', $filename, 'public');
            $user->profile_photo = asset('storage/' . $path);
        }

        $user->save();

        return response()->json($user, 200);
    }
}
