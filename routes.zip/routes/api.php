<?php

use App\Http\Controllers\CommentController;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\GroupController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Private Groups
|--------------------------------------------------------------------------
*/
Route::middleware('auth:sanctum')->get('my-private-groups', function (Request $request) {
    $user = $request->user();
    $groups = $user->groups()->where('is_public', false)->withCount('members')->get();

    // Oculta la clave si no eres el creador
    $groups->transform(function ($group) use ($user) {
        if ($group->created_by !== $user->id) {
            unset($group->access_key);
        }
        return $group;
    });

    return response()->json($groups, 200);
});

/*
|--------------------------------------------------------------------------
| My Groups
|--------------------------------------------------------------------------
*/
Route::middleware('auth:sanctum')->get('my-groups', function (Request $request) {
    return response()->json(
        $request->user()->groups()->withCount('members')->get(),
        200
    );
});

/*
|--------------------------------------------------------------------------
| User Profile (view/update)
|--------------------------------------------------------------------------
*/
Route::middleware('auth:sanctum')->group(function () {
    Route::get('user', function (Request $request) {
        return response()->json($request->user(), 200);
    });

    Route::put('user', [UserController::class, 'update']);
});

/*
|--------------------------------------------------------------------------
| Authentication Routes
|--------------------------------------------------------------------------
*/
Route::controller(RegisteredUserController::class)->group(function () {
    Route::post('register', 'store')->middleware('guest')->name('register');
});

Route::controller(AuthenticatedSessionController::class)->group(function () {
    Route::post('login', 'store')->middleware('guest')->name('login');
    Route::delete('logout', 'destroy')->middleware('auth:sanctum')->name('logout');
});

/*
|--------------------------------------------------------------------------
| Public Group Routes
|--------------------------------------------------------------------------
*/
Route::controller(GroupController::class)->group(function () {
    Route::get('groups', 'index');
    Route::get('groups/{id}', 'show');
});

/*
|--------------------------------------------------------------------------
| Protected Group Routes
|--------------------------------------------------------------------------
*/
Route::middleware('auth:sanctum')->group(function () {
    Route::controller(GroupController::class)->group(function () {
        Route::post('groups', 'store');
        Route::put('groups/{id}', 'update');
        Route::delete('groups/{id}', 'destroy');
        Route::post('groups/{id}/join', 'join');
        Route::post('groups/{id}/leave', 'leave');
        Route::post('groups/join-by-code', 'joinByCode');
    });
});

/*
|--------------------------------------------------------------------------
| Public Post Routes
|--------------------------------------------------------------------------
*/
Route::controller(PostController::class)->group(function () {
    Route::get('posts', 'index');
    Route::get('posts/{id}', 'show');
});

/*
|--------------------------------------------------------------------------
| Protected Post & Comment Routes
|--------------------------------------------------------------------------
*/
Route::middleware('auth:sanctum')->group(function () {
    // Posts
    Route::controller(PostController::class)->group(function () {
        Route::post('posts', 'store');
        Route::put('posts/{id}', 'update');
        Route::delete('posts/{id}', 'destroy');
    });

    // Comments
    Route::controller(CommentController::class)->group(function () {
        Route::post('comments', 'store');
        Route::delete('comments/{id}', 'destroy');
    });
});

/*
|--------------------------------------------------------------------------
| Protected User Management Routes (Admin Only)
|--------------------------------------------------------------------------
|
| Estas rutas usan el middleware auth:sanctum y luego el closure en
| UserController::__construct() para garantizar que solo admin@gmail.com
| con la contraseña 12345678 pueda acceder.
|
*/
Route::middleware('auth:sanctum')->group(function () {
    Route::controller(UserController::class)->group(function () {
        Route::get('users',        'index');
        Route::post('users',       'store');
        Route::put('users/{id}',   'update');
        Route::delete('users/{id}','destroy');
    });
});
